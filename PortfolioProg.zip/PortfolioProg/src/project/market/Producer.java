package project.market;

//Die Klasse Producer ist der  Produzent, der Brot und Nudeln aus den Rohstoffen herstellt und diese dann an den Marktplatz liefert
public class Producer implements Runnable {
    private int finishedRuns = 0;
    public void run() {
        while(this.finishedRuns < 20) {
            this.produceNoodles();
            this.produceBread();
            this.produceNoodles();
            this.produceBread();
            try {
                Thread.sleep(MarketPlace.pause);
                this.finishedRuns++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    //Die Methode produceBread produziert Brot, aber nur wenn die Resourcen dafür vorhanden sind
    private void produceBread() {
        if (MarketPlace.salt > 0 && MarketPlace.ryeflour > 0 && MarketPlace.yeast > 0){
            MarketPlace.bread++;
            MarketPlace.salt--;
            MarketPlace.ryeflour--;
            MarketPlace.yeast--;
            System.out.println("Die Rohstoffe Salz, Roggenmehl und Hefe wurden verbraucht. \n" +
                    "Ein Brot wurde gebacken und an den Marktplatz geliefert! \n" + "Brot: " + MarketPlace.bread);
        }
    }

    //Die Methode produceNoodles produziert Nudeln, aber nur wenn die Ressourcen dafür vorhande sind.
    private void produceNoodles() {
        if (MarketPlace.water > 0 && MarketPlace.wheatflour > 0) {
            MarketPlace.noodles++;
            MarketPlace.water--;
            MarketPlace.wheatflour--;
            System.out.println("Die Rohstoffe Wasser und Weizenmehl wurden verbraucht. \n" +
                    "Ein Pack Nudeln wurde hergestellt und an den Marktplatz geliefert! \n" + "Nudeln: " + MarketPlace.noodles);
        }
    }
}
